﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Cafe_management_system.AllUserControls
{
    public partial class UC_Additem : UserControl
    {
        function fn = new function();
        String query;
        public UC_Additem()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            query = "insert into items (namee,category,price) values ('"+txtItemName.Text+"', '"+txtCategory.Text+"', "+txtPrice.Text+")";
            fn.setData(query);
            clearAll();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {

        }

        private void UC_Additem_Load(object sender, EventArgs e)
        {

        }

        public void clearAll()
        {
            txtCategory.SelectedIndex = -1;
            txtItemName.Clear();
            txtPrice.Clear();
        }

        private void UC_Additem_Leave(object sender, EventArgs e)
        {
            clearAll();
        }
    }
}
