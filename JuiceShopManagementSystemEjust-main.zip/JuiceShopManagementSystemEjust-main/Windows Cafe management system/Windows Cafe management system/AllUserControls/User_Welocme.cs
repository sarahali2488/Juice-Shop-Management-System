﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Cafe_management_system.AllUserControls
{
    public partial class User_Welocme : UserControl
    {
        public User_Welocme()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void User_Welocme_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
        int num = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (num == 0)
            {
                LabelBanner.Location = new Point(10,367);
                LabelBanner.ForeColor = Color.Orange;
                num++;
            }
            else if (num == 1)
            {
                LabelBanner.Location = new Point(166, 367);
                LabelBanner.ForeColor = Color.Green;
                num++;
            }
            else if (num == 2)
            {
                LabelBanner.Location = new Point(268, 367);
                LabelBanner.ForeColor = Color.RoyalBlue;
                num++;
            }
            else if (num == 3)
            {
                LabelBanner.Location = new Point(368, 367);
                LabelBanner.ForeColor = Color.Purple;
                num++;
            }
            else if (num == 4)
            {
                LabelBanner.Location = new Point(490, 367);
                LabelBanner.ForeColor = Color.Coral;
                num = 0;
            }
        }

        private void LabelBanner_Click(object sender, EventArgs e)
        {

        }
    }
}
